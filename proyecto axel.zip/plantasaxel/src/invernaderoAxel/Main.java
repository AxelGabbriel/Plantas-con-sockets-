//Axel Miquilena ci:28243093
package invernaderoAxel;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IUplantas v1 = new IUplantas();
		v1.setVisible(true);
	}

}
